from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import IPOViewSet, IPOStatsView, UserViewSet

router = DefaultRouter()
router.register(r'ipo', IPOViewSet)
router.register(r'users', UserViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('ipo/stats/', IPOStatsView.as_view(), name='ipo-stats'),
]
