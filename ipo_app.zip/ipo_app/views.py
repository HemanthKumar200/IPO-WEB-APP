from rest_framework import viewsets, filters
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.decorators import action
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db import models

from .models import IPO, CustomUser
from .serializers import IPOSerializer, UserSerializer

class UserViewSet(viewsets.ModelViewSet):
    queryset = CustomUser.objects.all()
    serializer_class = UserSerializer

class IPOStatsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        total_ipos = IPO.objects.count()
        # Refined query to only include listed IPOs with valid prices
        listed_ipos_with_prices = IPO.objects.filter(
            status='listed',
            listing_price__isnull=False,
            ipo_price__isnull=False
        )
        ipos_in_gain = listed_ipos_with_prices.filter(listing_price__gt=models.F('ipo_price')).count()
        ipos_in_loss = listed_ipos_with_prices.filter(listing_price__lt=models.F('ipo_price')).count()

        data = {
            'total_ipos': total_ipos,
            'ipos_in_gain': ipos_in_gain,
            'ipos_in_loss': ipos_in_loss,
        }
        return Response(data)

class IPOViewSet(viewsets.ModelViewSet):
    queryset = IPO.objects.all()
    serializer_class = IPOSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['company_name']
    ordering_fields = ['ipo_price', 'open_date', 'listing_date']

    def get_permissions(self):
        """
        Instantiates and returns the list of permissions that this view requires.
        """
        if self.action in ['list', 'retrieve']:
            permission_classes = [AllowAny]
        else:
            permission_classes = [IsAuthenticated]
        return [permission() for permission in permission_classes]

    @action(detail=False, methods=['get'])
    def stats_main_board(self, request):
        upcoming_ipos = IPO.objects.filter(status='upcoming').count()
        new_listed_ipos = IPO.objects.filter(status='listed').count()
        ongoing_ipos = IPO.objects.filter(status='ongoing').count()

        data = {
            'upcoming': upcoming_ipos,
            'new_listed': new_listed_ipos,
            'ongoing': ongoing_ipos,
        }
        return Response(data)

