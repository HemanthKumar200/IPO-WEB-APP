import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import AdminHeader from './AdminHeader';
import './AdminDashboard.css';

const AdminDashboard = () => (
  <div className="admin-dashboard">
    <Sidebar />
    <main className="main-content">
      <AdminHeader />
      <Outlet />
    </main>
  </div>
);

export default AdminDashboard; 