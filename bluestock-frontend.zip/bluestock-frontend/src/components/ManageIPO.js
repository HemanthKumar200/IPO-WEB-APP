import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import './ManageIPO.css';

const ManageIPO = () => {
    const [ipos, setIpos] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [editIpo, setEditIpo] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [form, setForm] = useState({});
    const iposPerPage = 9;
    const navigate = useNavigate();

    useEffect(() => {
        const fetchIPOs = async () => {
            const token = localStorage.getItem('accessToken');
            if (!token) {
                navigate('/login');
                return;
            }

            try {
                const response = await axios.get('http://127.0.0.1:8000/api/ipo/', {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setIpos(response.data);
            } catch (error) {
                console.error('Error fetching IPOs:', error);
                if (error.response && error.response.status === 401) {
                    navigate('/login');
                }
            }
        };

        fetchIPOs();
    }, [navigate]);

    const handleDelete = async (id) => {
        const token = localStorage.getItem('accessToken');
        if (!token) {
            navigate('/login');
            return;
        }

        if (window.confirm('Are you sure you want to delete this IPO?')) {
            try {
                await axios.delete(`http://127.0.0.1:8000/api/ipo/${id}/`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setIpos(ipos.filter((ipo) => ipo.id !== id));
            } catch (error) {
                console.error('Error deleting IPO:', error);
                alert('Failed to delete IPO.');
            }
        }
    };

    // Pagination logic
    const indexOfLastIpo = currentPage * iposPerPage;
    const indexOfFirstIpo = indexOfLastIpo - iposPerPage;
    const currentIpos = ipos.slice(indexOfFirstIpo, indexOfLastIpo);
    const totalPages = Math.ceil(ipos.length / iposPerPage);

    const handlePageChange = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    // Update Modal logic
    const openUpdateModal = (ipo) => {
        setEditIpo(ipo);
        setForm({ ...ipo });
        setShowModal(true);
    };
    const closeModal = () => {
        setShowModal(false);
        setEditIpo(null);
    };
    const handleFormChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };
    const handleUpdateSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('accessToken');
        if (!token) {
            navigate('/login');
            return;
        }
        try {
            await axios.put(`http://127.0.0.1:8000/api/ipo/${editIpo.id}/`, form, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            setIpos(ipos.map((ipo) => (ipo.id === editIpo.id ? { ...form } : ipo)));
            closeModal();
        } catch (error) {
            alert('Failed to update IPO.');
        }
    };

    return (
        <div className="manage-ipo-container">
            <div className="header">
                <h1>Upcoming IPO | Dashboard</h1>
                <Link to="/admin/register-ipo" className="register-ipo-btn">Register IPO</Link>
            </div>
            <div className="table-responsive">
                <table className="ipo-table">
                    <thead>
                        <tr>
                            <th>Company</th>
                            <th>Price Band</th>
                            <th>Open</th>
                            <th>Close</th>
                            <th>ISSUE SIZE</th>
                            <th>ISSUE Type</th>
                            <th>Listing Date</th>
                            <th>Status</th>
                            <th>Action</th>
                            <th>Delete/View</th>
                        </tr>
                    </thead>
                    <tbody>
                        {currentIpos.map((ipo) => (
                            <tr key={ipo.id}>
                                <td>{ipo.company_name}</td>
                                <td>₹ {ipo.price_band}</td>
                                <td>{ipo.open_date}</td>
                                <td>{ipo.close_date}</td>
                                <td>{ipo.issue_size}</td>
                                <td>{ipo.issue_type}</td>
                                <td>{ipo.listing_date}</td>
                                <td><span className={`status ${ipo.status.toLowerCase().replace(' ', '-')}`}>{ipo.status}</span></td>
                                <td><button className="action-btn update" onClick={() => openUpdateModal(ipo)}>Update</button></td>
                                <td>
                                    <button className="icon-btn delete" onClick={() => handleDelete(ipo.id)}>🗑️</button>
                                    <button className="icon-btn view">👁️</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="pagination">
                <button
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                >
                    &lt;
                </button>
                {[...Array(totalPages).keys()].map(number => (
                    <button
                        key={number + 1}
                        onClick={() => handlePageChange(number + 1)}
                        className={currentPage === number + 1 ? 'active' : ''}
                    >
                        {number + 1}
                    </button>
                ))}
                <button
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                >
                    &gt;
                </button>
            </div>
            {showModal && (
                <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.3)', zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <div style={{ background: '#fff', padding: 24, borderRadius: 8, minWidth: 320, maxWidth: 400 }}>
                        <h2>Update IPO</h2>
                        <form onSubmit={handleUpdateSubmit}>
                            <div style={{ marginBottom: 12 }}>
                                <label>Company Name</label>
                                <input name="company_name" value={form.company_name || ''} onChange={handleFormChange} required />
                            </div>
                            <div style={{ marginBottom: 12 }}>
                                <label>Price Band</label>
                                <input name="price_band" value={form.price_band || ''} onChange={handleFormChange} required />
                            </div>
                            <div style={{ marginBottom: 12 }}>
                                <label>Open Date</label>
                                <input name="open_date" value={form.open_date || ''} onChange={handleFormChange} required />
                            </div>
                            <div style={{ marginBottom: 12 }}>
                                <label>Close Date</label>
                                <input name="close_date" value={form.close_date || ''} onChange={handleFormChange} required />
                            </div>
                            <div style={{ marginBottom: 12 }}>
                                <label>Issue Size</label>
                                <input name="issue_size" value={form.issue_size || ''} onChange={handleFormChange} required />
                            </div>
                            <div style={{ marginBottom: 12 }}>
                                <label>Issue Type</label>
                                <input name="issue_type" value={form.issue_type || ''} onChange={handleFormChange} required />
                            </div>
                            <div style={{ marginBottom: 12 }}>
                                <label>Listing Date</label>
                                <input name="listing_date" value={form.listing_date || ''} onChange={handleFormChange} required />
                            </div>
                            <div style={{ marginBottom: 12 }}>
                                <label>Status</label>
                                <input name="status" value={form.status || ''} onChange={handleFormChange} required />
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
                                <button type="button" onClick={closeModal}>Cancel</button>
                                <button type="submit" className="action-btn update">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ManageIPO; 