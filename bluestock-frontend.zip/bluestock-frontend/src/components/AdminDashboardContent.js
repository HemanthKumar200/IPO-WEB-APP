import React from 'react';
import IPOStats from './IPOStats';
import QuickLinks from './QuickLinks';
import MainBoardIPO from './MainBoardIPO';

const AdminDashboardContent = () => (
  <div className="dashboard-grid">
    <div className="grid-item-stats">
      <IPOStats />
    </div>
    <div className="grid-item-quick-links">
      <QuickLinks />
    </div>
    <div className="grid-item-main-board">
      <MainBoardIPO />
    </div>
  </div>
);

export default AdminDashboardContent; 