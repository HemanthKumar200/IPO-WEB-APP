import React, { useState } from 'react';
import './FAQ.css';

const faqs = [
  {
    question: 'How to Subscribe to an IPO?',
    answer: 'Step 1: Login to your respective service provider.<br/>Step 2: Click on the IPO button.<br/>Step 3: Select the IPO you want to bid and enter the relevant details.<br/>Step 4: Your subscription will be completed once you make the payment or give permission.',
  },
  {
    question: 'Should I buy an IPO first day?',
    answer: 'This is a personal investment decision. It is recommended to do your own research or consult a financial advisor.',
  },
  {
    question: 'How do you know if an IPO is good?',
    answer: 'Evaluating an IPO involves analyzing the company\'s financials, management, industry, and the IPO\'s valuation. Reading the DRHP and RHP documents is crucial.',
  },
  {
    question: 'How to check IPO start date?',
    answer: 'The IPO start date is usually announced a week or two before the opening of the issue. You can find this information on financial news websites, the stock exchange\'s website, or in the IPO prospectus.',
  },
  {
    question: 'What is issue size?',
    answer: 'The issue size is the total value of the shares being offered by the company in the IPO. It is calculated by multiplying the number of shares offered by the issue price per share.',
  },
  {
    question: 'How many shares in a lot?',
    answer: 'The number of shares in a lot is determined by the company in consultation with its merchant bankers. The lot size is fixed in such a way that the value of one lot is within a certain range (e.g., ₹14,000 to ₹15,000 for retail investors).',
  },
  {
    question: 'How is the lot size calculated?',
    answer: 'The lot size is calculated by dividing the upper end of the price band by the minimum application amount. For example, if the price band is ₹100-₹110 and the minimum application is ₹14,300, the lot size would be 130 shares (14300/110, rounded down).',
  },
  {
    question: 'Who decides the IPO price band?',
    answer: 'The price band is decided by the company in consultation with the book running lead managers (BRLMs) based on demand from institutional investors during the book-building process.',
  },
  {
    question: 'What is IPO GMP?',
    answer: 'GMP stands for Grey Market Premium. It is the premium at which IPO shares are traded in the grey market before they are listed on the stock exchange. It is an unofficial indicator of demand for the IPO.',
  },
  {
    question: 'How many lots should I apply for IPO?',
    answer: 'Retail individual investors can apply for lots up to a maximum of ₹2,00,000. The number of lots you should apply for depends on your budget and your assessment of the IPO.',
  },
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(0);

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="faq-container">
      <h2>Frequently Asked Questions?</h2>
      <p className="faq-subtitle">Find answers to common questions that come in your mind related to IPO.</p>
      <div className="faq-list">
        {faqs.map((faq, index) => (
          <div key={index} className="faq-item">
            <div className="faq-question" onClick={() => toggleFAQ(index)}>
              <span>{faq.question}</span>
              <span>{openIndex === index ? '-' : '+'}</span>
            </div>
            {openIndex === index && (
              <div
                className="faq-answer"
                dangerouslySetInnerHTML={{ __html: faq.answer }}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQ; 