import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './SignUp.css';

const SignUp = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://127.0.0.1:8000/api/users/', {
        username: name,
        email: email,
        password: password,
      });
      // Redirect to login after successful signup
      navigate('/login');
    } catch (error) {
      console.error('Signup failed:', error);
      alert('Signup failed. Please try again.');
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <span className="logo-text">BLUESTOCK</span>
          <h2>Create an account</h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Name</label>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="input-group">
            <label>Email Address</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="input-group">
            <label>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <div className="terms-text">
            By certifying, you agree to our <a href="#terms">terms of service.</a>
          </div>
          <div className="captcha-placeholder">
            [I'm not a robot - reCAPTCHA]
          </div>
          <button type="submit" className="auth-btn">Sign Up</button>
        </form>
        <div className="social-signup">
          <div className="divider">or sign up with</div>
          <button className="google-btn">Continue with Google</button>
        </div>
        <div className="switch-auth">
          Already have an account? <Link to="/login">Sign in here</Link>
        </div>
      </div>
    </div>
  );
};

export default SignUp; 