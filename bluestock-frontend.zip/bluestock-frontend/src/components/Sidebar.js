import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FiGrid, FiList, FiTrendingUp, FiCheckCircle, FiSettings, FiCpu, FiUsers, FiHelpCircle, FiMenu } from 'react-icons/fi';
import './Sidebar.css';

const Sidebar = () => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        className="sidebar-toggle"
        aria-label="Open sidebar menu"
        onClick={() => setOpen(!open)}
      >
        <FiMenu />
      </button>
      <aside className={`sidebar${open ? ' open' : ''}`} onClick={() => setOpen(false)}>
        <div className="sidebar-header">
          <span className="sidebar-logo">Bluestock Fintech</span>
        </div>
        <nav className="sidebar-nav">
          <p className="menu-header">MENU</p>
          <Link to="/admin" className="nav-link active"><FiGrid className="nav-icon" /> Dashboard</Link>
          <p className="menu-header">IPO</p>
          <Link to="/admin/manage-ipo" className="nav-link"><FiList className="nav-icon" /> Manage IPO</Link>
          <Link to="/admin/ipo-subscription" className="nav-link"><FiTrendingUp className="nav-icon" /> IPO Subscription</Link>
          <Link to="/admin/ipo-allotment" className="nav-link"><FiCheckCircle className="nav-icon" /> IPO Allotment</Link>
          <p className="menu-header">OTHERS</p>
          <Link to="/admin/settings" className="nav-link"><FiSettings className="nav-icon" /> Settings</Link>
          <Link to="/admin/api-manager" className="nav-link"><FiCpu className="nav-icon" /> API Manager</Link>
          <Link to="/admin/accounts" className="nav-link"><FiUsers className="nav-icon" /> Accounts</Link>
          <Link to="/admin/help" className="nav-link"><FiHelpCircle className="nav-icon" /> Help</Link>
        </nav>
      </aside>
    </>
  );
};

export default Sidebar; 