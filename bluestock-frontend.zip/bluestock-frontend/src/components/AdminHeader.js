import React from 'react';
import { FiBell } from 'react-icons/fi';
import './AdminHeader.css';

const AdminHeader = () => {
  const username = localStorage.getItem('username') || 'User';
  return (
    <div className="admin-header">
      <div className="search-bar">
        <input type="text" placeholder="Search" />
      </div>
      <div className="user-profile">
        <FiBell className="header-icon" />
        <span>Hi, {username}</span>
        <span className="user-avatar">{username.charAt(0).toUpperCase()}</span>
      </div>
    </div>
  );
};

export default AdminHeader; 