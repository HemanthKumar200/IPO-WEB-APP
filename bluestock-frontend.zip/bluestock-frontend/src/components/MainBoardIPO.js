import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { PieChart, Pie, Cell, Tooltip } from 'recharts';
import './MainBoardIPO.css';

const COLORS = ['#a393eb', '#6ee7b7', '#fca5a5'];

const MainBoardIPO = () => {
    const [stats, setStats] = useState({
        upcoming: 0,
        new_listed: 0,
        ongoing: 0,
    });
    const navigate = useNavigate();

    useEffect(() => {
        const fetchStats = async () => {
            const token = localStorage.getItem('accessToken');
            if (!token) {
                navigate('/login');
                return;
            }

            try {
                const response = await axios.get('http://127.0.0.1:8000/api/ipo/stats_main_board/', {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setStats(response.data);
            } catch (error) {
                console.error('Error fetching main board IPO stats:', error);
                if (error.response && error.response.status === 401) {
                    navigate('/login');
                }
            }
        };

        fetchStats();
    }, [navigate]);

    const data = [
        { name: 'Upcoming', value: stats.upcoming },
        { name: 'New Listed', value: stats.new_listed },
        { name: 'Ongoing', value: stats.ongoing },
    ];
    const total = stats.upcoming + stats.new_listed + stats.ongoing;

    return (
        <div className="main-board-ipo-card">
            <div className="card-header">
                <h3>Main Board IPO</h3>
                <span>From 01 Jan 2024</span>
                <a href="#view-report" className="view-report-link">View Report</a>
            </div>
            <div className="chart-container">
                <PieChart width={200} height={200}>
                    <Pie
                        data={data}
                        cx={100}
                        cy={100}
                        innerRadius={60}
                        outerRadius={90}
                        fill="#8884d8"
                        paddingAngle={2}
                        dataKey="value"
                        stroke="none"
                    >
                        {data.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Pie>
                    <Tooltip />
                    <foreignObject x={60} y={80} width={80} height={60} style={{ pointerEvents: 'none' }}>
                        <div className="chart-center-text">
                            <div className="chart-value">{total}</div>
                            <div className="chart-label">Total</div>
                            <div className="chart-sublabel">IPO/NSE & BSE</div>
                        </div>
                    </foreignObject>
                </PieChart>
                <div className="chart-legend">
                    <div className="legend-item">
                        <span className="legend-dot upcoming"></span>
                        Upcoming
                        <span className="legend-value">{stats.upcoming}</span>
                    </div>
                    <div className="legend-item">
                        <span className="legend-dot new-listed"></span>
                        New Listed
                        <span className="legend-value">{stats.new_listed}</span>
                    </div>
                    <div className="legend-item">
                        <span className="legend-dot ongoing"></span>
                        Ongoing
                        <span className="legend-value">{stats.ongoing}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MainBoardIPO; 