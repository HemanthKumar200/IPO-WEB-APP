import React from 'react';
import nseLogo from '../assets/10.png';
import bseLogo from '../assets/11.jpg';
import sebiLogo from '../assets/12.png';
import moneyControlLogo from '../assets/13.jpg';
import './QuickLinks.css';

const quickLinksData = [
    { name: 'NSE India', url: '#', logo: nseLogo },
    { name: 'BSE India', url: '#', logo: bseLogo },
    { name: 'SEBI', url: '#', logo: sebiLogo },
    { name: 'Money Control', url: '#', logo: moneyControlLogo },
];

const QuickLinks = () => {
    return (
        <div className="quick-links-card">
            <h3>Quick Links</h3>
            <p className="quick-links-subtitle">Adipiscing elit, sed do eiusmod tempor</p>
            <ul>
                {quickLinksData.map((link, index) => (
                    <li key={index}>
                        <a href={link.url}>
                            <img src={link.logo} alt={link.name} className="quick-link-logo" />
                            <span>{link.name}</span>
                            <span>Visit Now</span>
                        </a>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default QuickLinks; 