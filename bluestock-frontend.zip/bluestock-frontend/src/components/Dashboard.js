// src/components/Dashboard.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Dashboard.css';
import FAQ from './FAQ';

const Dashboard = () => {
  const [ipoData, setIpoData] = useState([]);

  useEffect(() => {
    const fetchIPOs = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8000/api/ipo/');
        setIpoData(response.data);
      } catch (error) {
        console.error('Error fetching IPO data:', error);
      }
    };

    fetchIPOs();
  }, []);

  return (
    <div className="dashboard-layout">
      <div className="upcoming-ipo-container">
        <div className="header">
          <p className="breadcrumb">#Bluestock > IPO > Upcoming IPO</p>
          <h1>Upcoming IPO</h1>
          <p>Companies that have filed for an IPO with SEBI. Few details might be disclosed by the companies later.</p>
        </div>
        <div className="ipo-grid">
          {ipoData.map((ipo, index) => (
            <div key={index} className="ipo-card">
              <div className="ipo-card-header">
                <img src={ipo.logo} alt={`${ipo.company_name} logo`} className="company-logo" />
                <h2 className="company-name">{ipo.company_name}</h2>
              </div>
              <div className="ipo-details-grid">
                <div className="detail-item">
                  <span className="detail-title">PRICE BAND</span>
                  <span className="detail-value">{ipo.price_band}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-title">OPEN</span>
                  <span className="detail-value">{ipo.open_date}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-title">CLOSE</span>
                  <span className="detail-value">{ipo.close_date}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-title">ISSUE SIZE</span>
                  <span className="detail-value">{ipo.issue_size}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-title">ISSUE TYPE</span>
                  <span className="detail-value">{ipo.issue_type}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-title">LISTING DATE</span>
                  <span className="detail-value">{ipo.listing_date}</span>
                </div>
              </div>
              <div className="ipo-card-footer">
                <a href={ipo.rhp_pdf} target="_blank" rel="noopener noreferrer" className="btn rhp-btn">RHP</a>
                <a href={ipo.drhp_pdf} target="_blank" rel="noopener noreferrer" className="btn drhp-btn">DRHP</a>
              </div>
            </div>
          ))}
        </div>
      </div>
      <FAQ />
    </div>
  );
};

export default Dashboard;
