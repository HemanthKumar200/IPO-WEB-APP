import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './RegisterIPO.css';

const RegisterIPO = () => {
  const [formData, setFormData] = useState({
    company_name: '',
    logo: null,
    price_band: '',
    open_date: '',
    close_date: '',
    issue_size: '',
    issue_type: '',
    listing_date: '',
    status: 'upcoming',
    rhp_pdf: null,
    drhp_pdf: null,
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files) {
      setFormData({ ...formData, [name]: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const postData = new FormData();
    for (const key in formData) {
      postData.append(key, formData[key]);
    }

    try {
      const accessToken = localStorage.getItem('accessToken');
      await axios.post('http://127.0.0.1:8000/api/ipo/', postData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      alert('IPO registered successfully!');
      navigate('/admin/manage-ipo');
    } catch (error) {
      console.error('Error registering IPO:', error);
      alert('Failed to register IPO.');
    }
  };

  return (
    <div className="register-ipo-container">
      <h2>Register New IPO</h2>
      <form onSubmit={handleSubmit} className="register-ipo-form">
        <div className="form-grid">
          <div className="form-group">
            <label>Company Name</label>
            <input type="text" name="company_name" onChange={handleChange} required />
          </div>
          <div className="form-group">
            <label>Price Band</label>
            <input type="text" name="price_band" onChange={handleChange} required />
          </div>
          <div className="form-group">
            <label>Open Date</label>
            <input type="date" name="open_date" onChange={handleChange} required />
          </div>
          <div className="form-group">
            <label>Close Date</label>
            <input type="date" name="close_date" onChange={handleChange} required />
          </div>
          <div className="form-group">
            <label>Issue Size</label>
            <input type="text" name="issue_size" onChange={handleChange} required />
          </div>
          <div className="form-group">
            <label>Issue Type</label>
            <input type="text" name="issue_type" onChange={handleChange} required />
          </div>
          <div className="form-group">
            <label>Listing Date</label>
            <input type="date" name="listing_date" onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>Status</label>
            <select name="status" value={formData.status} onChange={handleChange}>
              <option value="upcoming">Upcoming</option>
              <option value="ongoing">Ongoing</option>
              <option value="listed">Listed</option>
            </select>
          </div>
          <div className="form-group">
            <label>Company Logo</label>
            <input type="file" name="logo" onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>RHP PDF</label>
            <input type="file" name="rhp_pdf" onChange={handleChange} />
          </div>
          <div className="form-group">
            <label>DRHP PDF</label>
            <input type="file" name="drhp_pdf" onChange={handleChange} />
          </div>
        </div>
        <button type="submit" className="submit-btn">Register IPO</button>
      </form>
    </div>
  );
};

export default RegisterIPO; 