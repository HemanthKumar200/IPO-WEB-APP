import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './IPOStats.css';

const IPOStats = () => {
  const [stats, setStats] = useState({
    total_ipos: 0,
    ipos_in_gain: 0,
    ipos_in_loss: 0,
  });
  const navigate = useNavigate();

  useEffect(() => {
    const fetchStats = async () => {
      const token = localStorage.getItem('accessToken');
      if (!token) {
        navigate('/login');
        return;
      }

      try {
        const response = await axios.get('http://127.0.0.1:8000/api/ipo/stats/', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setStats(response.data);
      } catch (error) {
        console.error('Error fetching IPO stats:', error);
        if (error.response && error.response.status === 401) {
          navigate('/login');
        }
      }
    };

    fetchStats();
  }, [navigate]);

  return (
    <div className="ipo-stats-card">
      <h3>IPO Dashboard India</h3>
      <p className="ipo-gain-indicator">↑ {stats.ipos_in_gain} IPO in Gain</p>
      <div className="stats-bubbles-abs">
        <div className="bubble loss abs-loss">
          <div className="bubble-value">{stats.ipos_in_loss}</div>
          <div className="bubble-label">IPO in Loss</div>
        </div>
        <div className="bubble total abs-total">
          <div className="bubble-value">{stats.total_ipos}</div>
          <div className="bubble-label">Total IPO</div>
        </div>
        <div className="bubble gain abs-gain">
          <div className="bubble-value">{stats.ipos_in_gain}</div>
          <div className="bubble-label">IPO in Gain</div>
        </div>
      </div>
    </div>
  );
};

export default IPOStats; 