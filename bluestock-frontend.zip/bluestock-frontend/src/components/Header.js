import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Header.css';

const Header = () => {
  const navigate = useNavigate();
  const accessToken = localStorage.getItem('accessToken');

  const handleLogout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    navigate('/');
    window.location.reload(); // Force a reload to update the header
  };

  return (
    <header className="app-header">
      <div className="header-content">
        <div className="logo-container">
          {/* <img src={logo} alt="Bluestock" className="logo" /> */}
          <span className="logo-text">BLUESTOCK</span>
        </div>
        <nav className="main-nav">
          <a href="#products">PRODUCTS</a>
          <a href="#pricing">PRICING</a>
          <a href="#community">COMMUNITY</a>
          <a href="#media">MEDIA</a>
          <a href="#support">SUPPORT</a>
        </nav>
        <div className="header-actions">
          {accessToken ? (
            <>
              <span className="user-email">h@gmail.com</span>
              <button onClick={handleLogout} className="logout-btn">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="signin-link">Sign In</Link>
              <Link to="/signup" className="signup-btn">Sign Up Now</Link>
            </>
          )}
          <div className="menu-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 12H3.01M6 12H6.01M9 12H9.01M12 12H12.01M15 12H15.01M18 12H18.01M21 12H21.01M3 6H3.01M6 6H6.01M9 6H9.01M12 6H12.01M15 6H15.01M18 6H18.01M21 6H21.01M3 18H3.01M6 18H6.01M9 18H9.01M12 18H12.01M15 18H15.01M18 18H18.01M21 18H21.01" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header; 