// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { GoogleOAuthProvider } from '@react-oauth/google';
import Header from './components/Header';
import Login from './components/login';
import Dashboard from './components/Dashboard';
import SignUp from './components/SignUp';
import ForgotPassword from './components/ForgotPassword';
import AdminDashboard from './components/AdminDashboard';
import AdminDashboardContent from './components/AdminDashboardContent';
import ManageIPO from './components/ManageIPO';
import RegisterIPO from './components/RegisterIPO';

function App() {
  const googleClientId = "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com"; // 🚨 Replace with your actual Google Client ID

  return (
    <GoogleOAuthProvider clientId={googleClientId}>
      <Router>
        <Routes>
          <Route path="/" element={<><Header /><Dashboard /></>} />
          <Route path="/dashboard" element={<Navigate to="/" />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/register-ipo" element={<Navigate to="/signup" />} />
          <Route path="/admin" element={<AdminDashboard />}>
            <Route index element={<AdminDashboardContent />} />
            <Route path="manage-ipo" element={<ManageIPO />} />
            <Route path="register-ipo" element={<RegisterIPO />} />
          </Route>
        </Routes>
      </Router>
    </GoogleOAuthProvider>
  );
}

export default App;
