# IPO Web App – Deployment Preparation & Technical Documentation

## 🚀 Deployment Preparation Checklist

### 1. Frontend (React)
- [x] All dependencies are installed (`npm install` in `bluestock-frontend`)
- [x] Production build works:
  ```bash
  cd bluestock-frontend
  npm run build
  ```
- [x] Environment variables (API URLs, etc.) are set in `.env` or handled securely
- [x] Remove/disable debug logs and test data
- [x] Responsive and cross-browser tested

### 2. Backend (Django)
- [x] All dependencies are installed (`pip install -r requirements.txt`)
- [x] `ALLOWED_HOSTS` and `DEBUG=False` in `settings.py`
- [x] Static/media files handled (`python manage.py collectstatic`)
- [x] Database migrations applied (`python manage.py migrate`)
- [x] Secure secret key and credentials
- [x] CORS configured for frontend domain

### 3. General
- [x] README with setup, usage, and deployment instructions
- [x] Remove unused files and secrets
- [x] Test user flows (login, CRUD, logout, error handling)
- [x] Prepare for HTTPS (SSL certs if needed)
- [x] Set up a process manager (e.g., Gunicorn, uWSGI for Django; serve React with Nginx/Apache or Vercel/Netlify)

---

## 📄 Technical Documentation

### Project Structure
```
IPO_Web_App/
  ├── bluestock-frontend/   # React frontend
  ├── ipo_app/              # Django app
  ├── ipo_project/          # Django project settings
  ├── manage.py             # Django entry point
  ├── db.sqlite3            # SQLite DB (use Postgres/MySQL for prod)
  └── static/, media/       # Static/media files
```

### Frontend
- **Framework:** React (with react-router, recharts, jwt-decode, etc.)
- **Build:**
  ```bash
  cd bluestock-frontend
  npm install
  npm run build
  ```
- **Deployment:**
  - Serve `build/` with Nginx, Apache, or a static host (Netlify, Vercel, etc.)
  - Set API base URL in `.env` if needed

### Backend
- **Framework:** Django + Django REST Framework
- **Run locally:**
  ```bash
  pip install -r requirements.txt
  python manage.py migrate
  python manage.py runserver
  ```
- **Production:**
  - Use Gunicorn/uWSGI + Nginx
  - Set `DEBUG=False`, configure `ALLOWED_HOSTS`
  - Collect static files: `python manage.py collectstatic`
  - Set up environment variables for secrets

### API
- **Auth:** JWT (SimpleJWT)
- **Endpoints:**
  - `/api/token/` (login)
  - `/api/ipo/` (CRUD IPOs)
  - `/api/ipo/stats/` (IPO stats)
  - ... (see Django views/urls for full list)

### Environment Variables
- **Frontend:**
  - `REACT_APP_API_URL=http://your-backend-domain/api/`
- **Backend:**
  - `SECRET_KEY`, `DEBUG`, `ALLOWED_HOSTS`, DB credentials

### Security
- Use HTTPS in production
- Never commit secrets or credentials
- Set CORS to allow only your frontend domain

### Testing
- Manual: Test all user flows (login, register, CRUD, logout)
- Automated: Add unit/integration tests as needed

---

## 📚 README Example (Short)

```
# IPO Web App

## Setup

### Backend (Django)
```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

### Frontend (React)
```bash
cd bluestock-frontend
npm install
npm run build
```

## Deployment

- Serve Django with Gunicorn/uWSGI + Nginx
- Serve React `build/` as static files
- Set environment variables for production

## Features

- JWT Auth
- Admin dashboard
- IPO CRUD
- Responsive UI

## License

MIT
``` 